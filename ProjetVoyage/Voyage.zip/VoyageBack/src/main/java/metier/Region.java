package metier;

public enum Region {
	Auvergne_Rh�ne_Alpes,
    Bourgogne_Franche_Comt�,
    Bretagne,
    Centre_Val_de_Loire,
    Corse,
    Grand_Est,
    Hauts_de_France,
    Ile_de_France,
    Normandie,
    Nouvelle_Aquitaine,
    Occitanie,
    Pays_de_la_Loire,
    Provence_Alpes_C�te_d_Azur;
}
